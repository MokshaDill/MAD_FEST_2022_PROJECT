import 'package:flutter/material.dart';

import 'FS_Contacts.dart';
import 'FS_home.dart';
import 'FS_Location.dart';
import 'FS_RaisHand.dart';

class MainPage extends StatefulWidget {
  const MainPage({Key? key}) : super(key: key);

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  final GlobalKey<ScaffoldState> _key = GlobalKey();

  List Pages = [
    const HomePage(),
    LocationPage(),
    const ContactPage(),
    MyCustomForm(),
  ];

  List Names = [
    "Home",
    "Location",
    "Contact",
    "Riase Hand",
  ];

  int currentIndex = 0;
  int name = 0;

  void onTap(int index) {
    setState(() {
      currentIndex = index;
      name = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _key,
      backgroundColor: Colors.lightGreen,
      body: Pages[currentIndex],
      bottomNavigationBar: BottomNavigationBar(unselectedFontSize: 0, selectedFontSize: 0, type: BottomNavigationBarType.fixed, backgroundColor: Colors.black12, onTap: onTap, currentIndex: currentIndex, selectedItemColor: Colors.lightGreen, unselectedItemColor: Colors.grey.withOpacity(1.0), showSelectedLabels: false, showUnselectedLabels: false, elevation: 0, items: const [
        BottomNavigationBarItem(
          icon: Icon(Icons.home),
          label: 'Home',
        ),
        BottomNavigationBarItem(icon: Icon(Icons.location_on_outlined), label: ('Location')),
        BottomNavigationBarItem(icon: Icon(Icons.add_box_rounded), label: ('contact')),
        BottomNavigationBarItem(icon: Icon(Icons.emoji_people), label: ('Raise Hand')),
      ]),
    );
  }
}
