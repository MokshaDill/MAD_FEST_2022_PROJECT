import 'package:flutter/material.dart';

class User {
  final String name;
  final String username;
  //final String description;
  final String image;
  final String address;
  final String contact_no;

  User(this.name, this.username, this.image, this.address, this.contact_no);
}

class ContactPage extends StatefulWidget {
  const ContactPage({Key? key}) : super(key: key);

  @override
  _ContactPageState createState() => _ContactPageState();
}

class _ContactPageState extends State<ContactPage> {
  final List<User> _users = [
    User(" Hotel Thilanka", "thilanka", "images/thilanka.jpg", "03 Sangamitta Mawatha, Kandy 20000", "0814 475 200"),
    User("Orient", "orient", "images/orient.jpg", "3XRW+P2C, Gampaha", "0332 236 450"),
    User("P&S", "p&s", "images/p&s.png", " 152 A Station Rd, Homagama", " 0117 898 349"),
  ];

  List<User> _foundedUsers = [];

  @override
  void initState() {
    super.initState();

    setState(() {
      _foundedUsers = _users;
    });
  }

  onSearch(String search) {
    setState(() {
      _foundedUsers = _users.where((user) => user.name.toLowerCase().contains(search)).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.grey,
        title: Container(
          height: 38,
          child: TextField(
            onChanged: (value) => onSearch(value),
            decoration: const InputDecoration(
                filled: true,
                fillColor: Colors.white24,
                contentPadding: EdgeInsets.all(0),
                prefixIcon: Icon(
                  Icons.search,
                  color: Colors.white,
                ),
                border: OutlineInputBorder(
                  borderSide: BorderSide.none,
                ),
                hintStyle: TextStyle(
                  fontSize: 14,
                  color: Colors.white,
                ),
                hintText: "Search Items"),
          ),
        ),
      ),
      body: Container(
          padding: EdgeInsets.only(right: 20, left: 20),
          color: Colors.black26,
          child: ListView.builder(
              itemCount: _foundedUsers.length,
              itemBuilder: (context, index) {
                return userComponent(user: _foundedUsers[index]);
              })),
    );
  }

  userComponent({required User user}) {
    return Container(
      // color: Colors.greenAccent,
      padding: EdgeInsets.only(top: 8, bottom: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Container(
                width: 60,
                height: 60,
                child: ClipRect(
                  child: Image.network(user.image),
                ),
              ),
              SizedBox(
                width: 10,
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    user.name,
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.w500),
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Text(
                    user.name,
                    style: TextStyle(color: Colors.grey[500]),
                  )
                ],
              )
            ],
          ),
        ],
      ),
    );
  }
}
